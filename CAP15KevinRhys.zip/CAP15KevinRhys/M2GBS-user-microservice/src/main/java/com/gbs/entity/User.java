package com.gbs.entity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USERS")
public class User {
//	RANDOM USER PASSWORD
	public static int NewRandom(int min, int max) {
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}

	@Id
	@Column(name = "USER_NAME")
	private String userName;
	@Column(name = "PASSWORD")
	private int password = NewRandom(1000, 9999);
	@Column(name = "CREATION_DATE")
	LocalDateTime creationDate = LocalDateTime.now();
	@Column(name = "NUMBER_OF_ACCOUNTS")
	private int numberOfAccounts;
	@Column(name = "LIST_OF_ACCOUNT_NUMBERS")
	private String listOfAccountNumbers;
	@Column(name = "TOTAL_BALANCE")
	private double totalBalance;
	@Column(name = "CONTACT_NUMBER")
	private String contactNumber;

	public User() {
		super();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

	public LocalDateTime getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDateTime creationDate) {
		this.creationDate = creationDate;
	}

	public int getNumberOfAccounts() {
		return numberOfAccounts;
	}

	public void setNumberOfAccounts(int numberOfAccounts) {
		this.numberOfAccounts = numberOfAccounts;
	}

	public String getListOfAccountNumbers() {
		return listOfAccountNumbers;
	}

	public void setListOfAccountNumbers(String listOfAccountNumbers) {
		this.listOfAccountNumbers = listOfAccountNumbers;
	}

	public double getTotalBalance() {
		return totalBalance;
	}

	public void setTotalBalance(double totalBalance) {
		this.totalBalance = totalBalance;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public boolean isPresent() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password + ", creationDate=" + creationDate
				+ ", numberOfAccounts=" + numberOfAccounts + ", listOfAccountNumbers=" + listOfAccountNumbers
				+ ", totalBalance=" + totalBalance + ", contactNumber=" + contactNumber + "]";
	}

}
