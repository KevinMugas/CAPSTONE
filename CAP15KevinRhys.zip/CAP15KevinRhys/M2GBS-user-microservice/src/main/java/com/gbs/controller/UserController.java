package com.gbs.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gbs.entity.User;
import com.gbs.entity.UsersResponse;
import com.gbs.repository.UserRepository;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserRepository userRepository;

	@GetMapping("/usersAsHTML")
	protected String getAllUsersAsHTML() {
		List<User> usersList = userRepository.findAll();
		String usersHTML = "<html><head><title>GBS App Accounts</title>"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\r\n"
				+ "    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\r\n"
				+ "    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\r\n"
				+ "    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script></head><body><h1>User Lists</h1>"
				+ "<table class=\"table table-dark table-striped\" style = \"width:1000px\"><tr><th>User Name</th><th>Password</th>"
				+ "<th>Creation Date</th><th>Number of Accounts</th><th>List of Account Numbers</th><th>Total Balance</th><th>Contact Number</th></tr>";
		for (User user : usersList) {
			usersHTML += "<tr><td>" + user.getUserName() + "</td><td>" + user.getPassword() + "</td><td>"
					+ user.getCreationDate() + "</td><td>" + user.getNumberOfAccounts() + "</td><td>"
					+ user.getListOfAccountNumbers() + "</td><td>Php " + String.format("%.0f", user.getTotalBalance())
					+ "</td><td>" + user.getContactNumber() + "</td></tr>";
		}
		usersHTML += "</table></body></html>";
		return usersHTML;
	}

//	GET ALL THE USERS	
	@GetMapping("/user")
	public List<User> getAllUsers() {
		List<User> usersList = userRepository.findAll();
		System.out.println(usersList);
		return usersList;
	}

//	CREATE USER
	@PostMapping("/users")
	public User createUser(@RequestBody User userFromBrowser) {
		System.out.println("Inserting : " + userFromBrowser);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		System.out.println(dtf.format(LocalDateTime.now()));
		User savedUser = userRepository.save(userFromBrowser);
		return savedUser;
	}

//	UPDATE TOTAL BALANCE
	@PatchMapping("/users/{userName}/{totalBalance}")
	public ResponseEntity<User> updateUserPartially(@PathVariable String userName, @PathVariable Double totalBalance,
			@RequestBody User userFromBrowser) {
		try {
			User userPatch = userRepository.findById(userName).get();
			userPatch.setTotalBalance(userFromBrowser.getTotalBalance());
			return new ResponseEntity<User>(userRepository.save(userPatch), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

//  UPDATE EXISTING USER
	@PutMapping("/users/{username}")
	public User updateProduct(@PathVariable(value = "username") String userName, @RequestBody User userFromBrowser) {
		System.out.println("Updating : " + userFromBrowser);
//		fetch the user from the database with the id
		User existingUser = userRepository.findById(userName).get();
		existingUser.setTotalBalance(userFromBrowser.getTotalBalance());
//		save the updated details
		User updatedUser = userRepository.save(existingUser);
		return updatedUser;
	}

// 	GET ALL THE USERSRESPONSE
	@GetMapping("/usersResponse")
	public UsersResponse getAllUserssResponse() {
		List<User> usersList = userRepository.findAll();
		UsersResponse usersResponse = new UsersResponse();
		usersResponse.setUsers(usersList);
		return usersResponse;
	}

}