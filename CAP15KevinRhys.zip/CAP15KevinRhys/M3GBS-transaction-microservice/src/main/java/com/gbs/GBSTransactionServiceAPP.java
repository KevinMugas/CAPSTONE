package com.gbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class GBSTransactionServiceAPP {
	public static void main(String[] args) {

		SpringApplication.run(GBSTransactionServiceAPP.class, args);
		System.out.println("GBS Transaction Service App");

	}
}