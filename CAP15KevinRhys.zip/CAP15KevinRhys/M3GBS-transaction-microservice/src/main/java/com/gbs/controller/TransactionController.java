package com.gbs.controller;


import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gbs.entity.Transaction;
import com.gbs.entity.TransactionsResponse;
import com.gbs.repository.TransactionRepository;


@RestController
@RequestMapping("/api")
public class TransactionController {

	@Autowired
	TransactionRepository transactionRepository;

	@GetMapping("/transactionsAsHTML")
	protected String getAllTransactionsAsHTML() {
		List<Transaction> transactionsList = transactionRepository.findAll();
		String transactionsHTML = "<html><head><title>GBS App Transactions List</title>"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\r\n"
				+ "    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\r\n"
				+ "    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\r\n"
				+ "    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script></head><body><h1>Transactions List</h1>"
				+ "<table class=\"table table-dark table-striped\" style = \"width:1000px\"><tr><th>Transaction Id</th><th>From Account</th><th>To Account</th><th>Amount</th></tr>";
		for (Transaction transaction : transactionsList) {
			transactionsHTML += "<tr><td>" + transaction.getTransactionId() + "</td><td>" + transaction.getFromAccount() + "</td><td>"
					+ transaction.getToAccount() + "</td><td>Php " + transaction.getAmount() + "</td></tr>";
		}
		transactionsHTML += "</table></body></html>";
		return transactionsHTML;
	}

//	GET ALL THE TRANSACTION
	@GetMapping("/transaction")
	public List<Transaction> getAllTransactions() {
		List<Transaction> transactionsList = transactionRepository.findAll();
		System.out.println(transactionsList);
		return transactionsList;
	}
	
//	GET ALL THE PRODUCTS
	@GetMapping("/transactionResponse")
	public TransactionsResponse getAllProductsResponse() {
		List<Transaction> transactionsList = transactionRepository.findAll();
		TransactionsResponse transactionsResponse = new TransactionsResponse();
		transactionsResponse.setTransaction(transactionsList);
		return transactionsResponse;
	}
	
//	CREATE TRANSACTION
	@PostMapping("/transaction")
	public Transaction createTransaction(@RequestBody Transaction transactionFromBrowser) {
		System.out.println("Inserting : " + transactionFromBrowser);
		Transaction savedTransaction = transactionRepository.save(transactionFromBrowser);
		return savedTransaction;
	}

}