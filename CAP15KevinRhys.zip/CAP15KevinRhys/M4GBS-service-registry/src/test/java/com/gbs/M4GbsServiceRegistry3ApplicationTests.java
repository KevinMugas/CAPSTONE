package com.gbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M4GbsServiceRegistry3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
