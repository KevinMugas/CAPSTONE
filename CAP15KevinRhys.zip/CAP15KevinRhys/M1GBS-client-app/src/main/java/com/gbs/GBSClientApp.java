package com.gbs;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.web.client.RestTemplate;

import com.gbs.model.Account;
import com.gbs.model.Transaction;
import com.gbs.model.User;
import com.gbs.stub.AccountsResponse;
import com.gbs.stub.TransactionsResponse;
import com.gbs.stub.UsersResponse;

public class GBSClientApp {
	public static void main(String[] args) throws InterruptedException {
		loginUser();
	}

//	LOGIN
	private static void loginUser() throws InterruptedException {
		int loginScanner = 0;

		while (loginScanner != 3) {
			try {
				System.out.println("System Starting . . . . . . . . . . . . . . .");
				Thread.sleep(3000);
				System.out.println("--------------------------------------------");
				System.out.println("             Welcome to GBS                 ");
				System.out.println("--------------------------------------------");
				System.out.println("[1] Login");
				System.out.println("[2] Show Transactions");
				System.out.println("[3] Shut Down");
				System.out.println();
				System.out.print("                       Enter Option [1-3]: ");

				loginScanner = new Scanner(System.in).nextInt();

				switch (loginScanner) {
				case 1:
//				USER INPUT
					Thread.sleep(1000);
					System.out.println();
					System.out.println("--------------------------------------------");
					System.out.println("Please login");
					System.out.println("--------------------------------------------");
					System.out.println();
					System.out.print("Enter User Name: ");
					String userNameInput = new Scanner(System.in).nextLine();

					System.out.print("Enter Password: ");
					int passwordInput = new Scanner(System.in).nextInt();
					System.out.println();
					System.out.println("--------------------------------------------");

//				VERIFICATION OF USER
					RestTemplate usersRestTemplate = new RestTemplate();
					final String restApiURLString = "http://localhost:8081/ecz/api/usersResponse";
					UsersResponse usersResponse = usersRestTemplate.getForObject(restApiURLString, UsersResponse.class);
					List<User> users = usersResponse.getUsers();
					for (User user : users) {
						String validateUserName = user.getUserName();
						if (validateUserName.equals(userNameInput)) {
							int validatePassword = user.getPassword();
							if (validatePassword == passwordInput) {
//							USER MENU
								Thread.sleep(1000);
								System.out.println();
								System.out.println("--------------------------------------------");
								System.out.println("       Welcome: " + userNameInput);
								System.out.println("--------------------------------------------");
								System.out.println("      Please choose a transaction:");
								System.out.println("--------------------------------------------");
								System.out.println("[1] Show Account Details");
								System.out.println("[2] Transfer Funds");
								System.out.println("[3] Search Transactions");
								System.out.print("                       Enter Option [1-3]: ");

								int transactionScanner = new Scanner(System.in).nextInt();
								if (transactionScanner == 1) {
//							DISPLAY DETAILS
									Thread.sleep(1000);
									System.out.println();
									System.out.println("--------------------------------------------");
									System.out.println("User Name          : " + user.getUserName());
									System.out.println("Password           : " + user.getPassword());
									System.out.println("Creation Date      : " + user.getCreationDate());
									System.out.println("Number Of Accounts : " + user.getNumberOfAccounts());
									System.out.println("List of Accounts   : " + user.getListOfAccountNumbers());
									System.out.println("Total Balance      : Php" + user.getTotalBalance());
									System.out.println("Contact Number     : " + user.getContactNumber());
									System.out.println("--------------------------------------------");
									loginScanner = 0;
								} else if (transactionScanner == 2) {
//								TRANSFER FUNDS
									String accountinputUserName = userNameInput;
									transferMoney(accountinputUserName, passwordInput);
									loginScanner = 0;
									break;
								} else if (transactionScanner == 3) {
//								SEARCH A CERTAIN TRANSACTION BY USER
//								USER INPUT TRANSACTION ID & VERIFY ACCOUNT NUMBER
//								ONLY USER CAN SEARCH FOR HIS/HER TRANSACTION AS LONG AS HE KNOWS THE TRANSACTION ID
									Thread.sleep(1000);
									System.out.println();
									System.out.println("--------------------------------------------");
									System.out.print("Enter Your Account Number: ");
									int accountNumberInput = new Scanner(System.in).nextInt();

//								FETCH TRANSACTION DATA
//								VERIFIES USER INPUT
									RestTemplate transactionsRestTemplate = new RestTemplate();
									final String transactionsrestApiURLString = "http://localhost:9092/ecz/api/transactionResponse";
									TransactionsResponse transactionsResponse = transactionsRestTemplate
											.getForObject(transactionsrestApiURLString, TransactionsResponse.class);
									int validateFromAccount = 0;
									String validateTransactionId = null;
									List<Transaction> transactions = transactionsResponse.getTransactions();
									for (Transaction transaction : transactions) {
										validateTransactionId = transaction.getTransactionId();
										if (validateTransactionId.equals(transaction.getTransactionId())) {
											validateFromAccount = transaction.getFromAccount();
											if (validateFromAccount == accountNumberInput) {
												Thread.sleep(1000);
												System.out.println();
												System.out.println("--------------------------------------------");
												System.out.println("Processing . . . ");
												System.out.println("--------------------------------------------");
												System.out.println();
												break;
											}
										}
									}

//								VERIFIES IF HE/SHE IS ALLOWED TO VIEW TRANSACTION
									if (validateFromAccount != accountNumberInput) {
										Thread.sleep(1000);
										System.out.println();
										System.out.println("--------------------------------------------");
										System.out.println("Invalid account number please try again.");
										System.out.println("--------------------------------------------");
										System.out.println();
										break;
									} else {
//									TRANSACTION DATA DISPLAY
										showUserTransaction(validateTransactionId, validateFromAccount);
										break;
									}

								}
							} else {
								Thread.sleep(1000);
								System.out.println();
								System.out.println("--------------------------------------------");
								System.out.println("Login Failed, Please try again.");
								System.out.println("--------------------------------------------");
								System.out.println();
								loginScanner = 0;
								break;
							}
						}
					}
					break;
				case 2:
//				SHOWS ALL TRANSACTION IN GBS
					getAllTransactions();
					loginScanner = 0;
					break;
				case 3:
//				TURNS OFF THE SYSTEM
					System.out.println();
					System.out.println("--------------------------------------------");
					System.out.println("System shutting down . . .");
					System.out.println("--------------------------------------------");
					System.out.println();
					Thread.sleep(1000);
					loginScanner = 3;
					break;
				}
			} catch (InputMismatchException inputMismatchException) {
				Thread.sleep(1000);
				System.out.println();
				System.out.println("--------------------------------------------");
				System.out.println("Invalid input please try again.\n");
				System.out.println("--------------------------------------------");
				System.out.println();
				loginScanner = 0;
			}
		}
	}

//	SHOW ALL TRANSACTION
	private static void getAllTransactions() throws InterruptedException {
		RestTemplate transactionsRestTemplate = new RestTemplate();
		final String restApiURLString = "http://localhost:9092/ecz/api/transactionResponse";
		TransactionsResponse transactionsResponse = transactionsRestTemplate.getForObject(restApiURLString,
				TransactionsResponse.class);
		Thread.sleep(1000);
		System.out.println();
		System.out.println("--------------------------------------------------------------");
		System.out.println(" | Trancation ID | From Account | To Account |    Ammount   |\r\n");
		for (Transaction transaction : transactionsResponse.getTransactions()) {
			System.out.println(" |   " + transaction.getTransactionId() + "  |   " + transaction.getFromAccount()
					+ "  |  " + transaction.getToAccount() + " |  Php " + transaction.getAmount() + "   |\n");
		}
		System.out.println("--------------------------------------------------------------");
		System.out.println();
	}

//	SHOW USER TRANSACTION
	private static void showUserTransaction(String validateTransactionId, int validateFromAccount)
			throws InterruptedException {
		RestTemplate transactionsRestTemplate = new RestTemplate();
		final String transactionsrestApiURLString = "http://localhost:9092/ecz/api/transactionResponse";
		TransactionsResponse transactionsResponse = transactionsRestTemplate.getForObject(transactionsrestApiURLString,
				TransactionsResponse.class);
		List<Transaction> transactions = transactionsResponse.getTransactions();
		for (Transaction transaction : transactions) {
//			String showvalidateTransactionId = transaction.getTransactionId();
			int fromConfirmation = transaction.getFromAccount();
			if (fromConfirmation == validateFromAccount) {
				Thread.sleep(1000);
				System.out.println();
				System.out.println("--------------------------------------------");
				System.out.println("You Transfer Money");
				System.out.println("Transactiod Id: " + transaction.getTransactionId());
				System.out.println("From Account  : " + transaction.getFromAccount());
				System.out.println("To Account    : " + transaction.getToAccount());
				System.out.println("Amount        : Php " + transaction.getAmount());
				System.out.println("--------------------------------------------");
				System.out.println();
			}
		}

		for (Transaction totransaction : transactions) {
//			String showvalidateTransactionId = transaction.getTransactionId();
			int fromConfirmation = totransaction.getToAccount();
			if (fromConfirmation == validateFromAccount) {
				Thread.sleep(1000);
				System.out.println();
				System.out.println("--------------------------------------------");
				System.out.println("You Reveived Money");
				System.out.println("Transactiod Id: " + totransaction.getTransactionId());
				System.out.println("From Account  : " + totransaction.getFromAccount());
				System.out.println("To Account    : " + totransaction.getToAccount());
				System.out.println("Amount        : Php " + totransaction.getAmount());
				System.out.println("--------------------------------------------");
				System.out.println();
			}
		}

	}

//	TRANSFER FUNDS MENU
	public static void transferMoney(String accountinputUserName, int passwordInput) throws InterruptedException {
		try {
			Thread.sleep(1000);
			System.out.println();
			System.out.println("---------------------------------------------------");
			System.out.println("Welcome " + accountinputUserName + " to Tranaction GBS");
			System.out.println("---------------------------------------------------");
			System.out.println();
			boolean transactCondition = false;
			String validateUserName = null;

			System.out.print("Enter Your Account Number: ");
			int accountNumberInput = new Scanner(System.in).nextInt();

			System.out.println("Transfer to");
			System.out.print("Enter Account Number: ");
			int toaccountNumberInput = new Scanner(System.in).nextInt();

			System.out.print("Enter Amount: Php ");
			double amountInput = new Scanner(System.in).nextDouble();

//		VALIDATIONN OF ACCOUNT NUMBER & USERNAME
			RestTemplate accountsRestTemplate = new RestTemplate();
			final String restApiURLString = "http://localhost:9091/ecz/api/accountsResponse";
			AccountsResponse accountsResponse = accountsRestTemplate.getForObject(restApiURLString,
					AccountsResponse.class);
			List<Account> accounts = accountsResponse.getAccounts();

			for (Account fromaccount : accounts) {
				Long validateAccountNumber = fromaccount.getAccountNumber();
				if (validateAccountNumber == accountNumberInput) {
					double validateAmount = fromaccount.getAccountBalance();
					if (validateAmount >= amountInput) {
						Thread.sleep(1000);
						System.out.println();
						System.out.println("---------------------------------------------------");
						System.out.println("Processing . . .");
						System.out.println("---------------------------------------------------");
						System.out.println();
						validateUserName = fromaccount.getUserName();
						transactCondition = true;
						break;
					} else {
						Thread.sleep(1000);
						System.out.println();
						System.out.println("---------------------------------------------------");
						System.out.println("Insufficient balance please try again.");
						System.out.println("---------------------------------------------------");
						System.out.println();
						break;
					}
				}
			}
			if (!validateUserName.equals(accountinputUserName)) {
				Thread.sleep(1000);
				System.out.println();
				System.out.println("---------------------------------------------------");
				System.out.println("Invalid account number please try again.");
				System.out.println("---------------------------------------------------");
				System.out.println();
			} else {
				fromTransfer(accountinputUserName, transactCondition, accountNumberInput, amountInput);
				toTransfer(accountinputUserName, transactCondition, accountNumberInput, toaccountNumberInput,
						amountInput);
			}
		} catch (InputMismatchException inputMismatchException) {
			Thread.sleep(1000);
			System.out.println();
			System.out.println("---------------------------------------------------");
			System.out.println("Invalid input please try again.");
			System.out.println("---------------------------------------------------");
			System.out.println();
		}
	}

//	FROM TRANSFER
	private static void fromTransfer(String accountinputUserName, boolean transactCondition, int accountNumberInput,
			Double amountInput) throws InterruptedException {
		if (transactCondition = true) {
			RestTemplate accountsRestTemplate = new RestTemplate();
			final String restApiURLString = "http://localhost:9091/ecz/api/accountsResponse";
			AccountsResponse accountsResponse = accountsRestTemplate.getForObject(restApiURLString,
					AccountsResponse.class);

			List<Account> accounts = accountsResponse.getAccounts();
			for (Account fromaccount : accounts) {
				Long validateAccountNumber = fromaccount.getAccountNumber();
				if (validateAccountNumber == accountNumberInput) {
					double validateAmount = fromaccount.getAccountBalance();
					if (validateAmount >= amountInput) {
						double currentBalance = validateAmount - amountInput;
						Account accountUpdate = new Account();
						accountUpdate.setUserName(fromaccount.getUserName());
						accountUpdate.setAccountNumber(fromaccount.getAccountNumber());
						accountUpdate.setAccountBalance(currentBalance);

						final String urlRESTAPIUpdate = "http://localhost:9091/ecz/api/accounts/"
								+ fromaccount.getAccountNumber();
						accountsRestTemplate.put(urlRESTAPIUpdate, accountUpdate);
						String validateUpdateUserName = fromaccount.getUserName();
						Thread.sleep(2000);
						System.out.println();
						System.out.println("---------------------------------------------------");
						System.out.println("You have succesfully transfered Php " + amountInput);
						System.out.println("Your remaining balance is       Php " + currentBalance);
						System.out.println("---------------------------------------------------");
						System.out.println();
						fromuserUpdate(validateUpdateUserName, amountInput);
						break;
					} else {
						Thread.sleep(1000);
						System.out.println();
						System.out.println("---------------------------------------------------");
						System.out.println("Insufficient balance please try again.");
						System.out.println("---------------------------------------------------");
						System.out.println();
						break;
					}
				}
			}
		}
	}

//	TO TRANSFER
	private static void toTransfer(String accountinputUserName, boolean transactCondition, int accountNumberInput,
			int toaccountNumberInput, Double amountInput) throws InterruptedException {
		if (transactCondition = true) {
			RestTemplate accountsRestTemplate = new RestTemplate();
			final String restApiURLString = "http://localhost:9091/ecz/api/accountsResponse";
			AccountsResponse accountsResponse = accountsRestTemplate.getForObject(restApiURLString,
					AccountsResponse.class);

			for (Account toaccount : accountsResponse.getAccounts()) {
				Long tovalidateAccountNumber = toaccount.getAccountNumber();
				if (tovalidateAccountNumber == toaccountNumberInput) {
					double currentBalance = toaccount.getAccountBalance() + amountInput;

					Account toaccountUpdate = new Account();
					toaccountUpdate.setUserName(toaccount.getUserName());
					toaccountUpdate.setAccountNumber(toaccount.getAccountNumber());
					toaccountUpdate.setAccountBalance(currentBalance);

					final String urlRESTAPIUpdate = "http://localhost:9091/ecz/api/accounts/"
							+ toaccount.getAccountNumber();
					accountsRestTemplate.put(urlRESTAPIUpdate, toaccountUpdate);
					String validateUpdateUserName = toaccountUpdate.getUserName();
					Thread.sleep(2000);
					transactionReceipt(accountNumberInput, toaccountNumberInput, amountInput);
					touserUpdate(validateUpdateUserName, amountInput);
					break;
				}
			}
		}
	}

//	TRANSACTION RECEIPT
	private static void transactionReceipt(int accountNumberInput, int toaccountNumberInput, Double amountInput)
			throws InterruptedException {
		RestTemplate transactionsRestTemplate = new RestTemplate();
		final String restApiURLString = "http://localhost:9092/ecz/api/transaction";
		Transaction transaction = new Transaction();

		transaction.setFromAccount(accountNumberInput);
		transaction.setToAccount(toaccountNumberInput);
		transaction.setAmount(amountInput);

		Transaction createdTransaction = transactionsRestTemplate.postForObject(restApiURLString, transaction,
				Transaction.class);
		Thread.sleep(1000);
		System.out.println();
		System.out.println("---------------------------------------------------");
		System.out.println("Transaction Succesful.");
		Thread.sleep(1000);
		System.out.println("Receipt");
		Thread.sleep(1000);
		System.out.println("Transaction id    : " + transaction.getTransactionId());
		System.out.println("From Account      : " + transaction.getFromAccount());
		System.out.println("To Account        : " + transaction.getToAccount());
		System.out.println("Amount Transfered : Php " + transaction.getAmount());
		System.out.println("---------------------------------------------------");
		System.out.println();
	}

//	USER FROM UPDATE
	private static void fromuserUpdate(String validateUpdateUserName, Double currentBalance)
			throws InterruptedException {

		RestTemplate usersRestTemplate = new RestTemplate();
		final String restApiURLString = "http://localhost:8081/ecz/api/usersResponse";
		UsersResponse usersResponse = usersRestTemplate.getForObject(restApiURLString, UsersResponse.class);

		List<User> users = usersResponse.getUsers();

		for (User user : users) {
			String validateUserName = user.getUserName();
			if (validateUserName.equals(validateUpdateUserName)) {
				String updateUserName = user.getUserName();
				Double previousTotalBalance = user.getTotalBalance();

				RestTemplate updateTotalBalanceRestTemplate = new RestTemplate();
				user.setTotalBalance(previousTotalBalance - currentBalance);
				final String totalBalanceApiURLString = "http://localhost:8081/ecz/api/users/" + updateUserName;
				updateTotalBalanceRestTemplate.put(totalBalanceApiURLString, user);

			}
		}
	}

//	TO USER UPDATE
	private static void touserUpdate(String validateUpdateUserName, Double currentBalance) throws InterruptedException {

		RestTemplate usersRestTemplate = new RestTemplate();
		final String restApiURLString = "http://localhost:8081/ecz/api/usersResponse";
		UsersResponse usersResponse = usersRestTemplate.getForObject(restApiURLString, UsersResponse.class);

		List<User> users = usersResponse.getUsers();

		for (User user : users) {
			String validateUserName = user.getUserName();
			if (validateUserName.equals(validateUpdateUserName)) {
				String updateUserName = user.getUserName();
				Double previousTotalBalance = user.getTotalBalance();

				RestTemplate updateTotalBalanceRestTemplate = new RestTemplate();
				user.setTotalBalance(previousTotalBalance + currentBalance);
				final String totalBalanceApiURLString = "http://localhost:8081/ecz/api/users/" + updateUserName;
				updateTotalBalanceRestTemplate.put(totalBalanceApiURLString, user);

			}
		}
	}

}