package com.gbs.stub;

import java.util.List;

import com.gbs.model.Transaction;

public class TransactionsResponse {
	private List<Transaction> transactions;

	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransaction(List<Transaction> transactions) {
		this.transactions = transactions;
	}
}
