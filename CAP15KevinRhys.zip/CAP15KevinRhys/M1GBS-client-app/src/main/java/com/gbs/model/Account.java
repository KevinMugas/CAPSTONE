package com.gbs.model;

import java.util.Random;

public class Account {
//	RANDOM USER PASSWORD
	public static int NewRandom(int min, int max) {
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}

	private Long accountNumber = (long) NewRandom(800000000, 999999999);

	private String userName;

	private double accountBalance;

	public Account() {
		super();
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", userName=" + userName + ", accountBalance="
				+ accountBalance + "]";
	}

}
