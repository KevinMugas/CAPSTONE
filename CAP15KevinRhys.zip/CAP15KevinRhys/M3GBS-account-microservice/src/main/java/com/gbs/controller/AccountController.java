package com.gbs.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gbs.entity.Account;
import com.gbs.entity.AccountsResponse;
import com.gbs.repository.AccountRepository;



@RestController
@RequestMapping("/api")
public class AccountController {

	@Autowired
	AccountRepository accountRepository;

	@GetMapping("/accountsAsHTML")
	protected String getAllUsersAsHTML() {
		List<Account> accountsList = accountRepository.findAll();
		String accountsHTML = "<html><head><title>GBS App Accounts List</title>"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\r\n"
				+ "    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\r\n"
				+ "    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\r\n"
				+ "    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script></head><body><h1>Accounts List</h1>"
				+ "<table class=\"table table-dark table-striped\" style = \"width:1000px\"><tr><th>Account Number</th><th>User Name</th><th>Account Balance</th></tr>";
		for (Account account : accountsList) {
			accountsHTML += "<tr><td>" + account.getAccountNumber() + "</td><td>" + account.getUserName() + "</td><td>Php "
					+ account.getAccountBalance() + "</td></tr>";
		}
		accountsHTML += "</table></body></html>";
		return accountsHTML;
	}

//	GET ALL THE ACCOUNTS	
	@GetMapping("/accounts")
	public List<Account> getAllAccounts() {
		List<Account> accountsList = accountRepository.findAll();
		System.out.println(accountsList);
		return accountsList;
	}
	
// 	GET ALL THE ACCOUNTRESPONSE
	@GetMapping("/accountsResponse")
	public AccountsResponse getAllAccountsResponse() {
		List<Account> accountsList = accountRepository.findAll();
		AccountsResponse accountsResponse = new AccountsResponse();
		accountsResponse.setAccounts(accountsList);
		return accountsResponse;
	}
	
//  UPDATE EXISTING ACCOUNT
	@PutMapping("/accounts/{id}")
	public Account updateAccount(@PathVariable(value = "id") Long accountNumber, @RequestBody Account accountFromBrowser) {
		System.out.println("Updating : " + accountFromBrowser);
		
//		fetch the user from the database with the id
		Account existingUser = accountRepository.findById(accountNumber).get();		
//		update the existing user with the details from the browser
		existingUser.setAccountNumber(accountFromBrowser.getAccountNumber());
		existingUser.setUserName(accountFromBrowser.getUserName());
		existingUser.setAccountBalance(accountFromBrowser.getAccountBalance());
//		save the updated details
		Account updatedAccount = accountRepository.save(existingUser);
		return updatedAccount;
	}

}